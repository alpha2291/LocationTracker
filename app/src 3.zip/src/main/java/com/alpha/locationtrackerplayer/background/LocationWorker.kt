package com.alpha.locationtrackerplayer.background

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.alpha.locationtrackerplayer.data.database.RealmManager
import com.alpha.locationtrackerplayer.data.model.LocationHistory
import com.google.android.gms.location.LocationServices
import io.github.xilinjia.krdb.ext.query
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.*

class LocationWorker(
    context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    companion object {
        private const val TAG = "LocationWorker"
    }

    override suspend fun doWork(): Result {

        val runAttempt = runAttemptCount
        val userId = inputData.getString("userId") ?: ""
        val now = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

        Log.d(TAG, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        Log.d(TAG, "▶ Worker STARTED")
        Log.d(TAG, "  Time       : $now")
        Log.d(TAG, "  UserId     : $userId")
        Log.d(TAG, "  Attempt #  : $runAttempt")
        Log.d(TAG, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

        if (userId.isBlank()) {
            Log.e(TAG, "✗ No userId provided — aborting worker")
            return Result.failure()
        }

        // ── Step 1: Get location ──────────────────────────────────────
        Log.d(TAG, "⏳ Requesting last known location from FusedLocationProvider...")

        val fusedLocationClient = LocationServices.getFusedLocationProviderClient(applicationContext)

        val location = try {
            fusedLocationClient.lastLocation.await()
        } catch (e: SecurityException) {
            Log.e(TAG, "✗ Location permission denied: ${e.message}")
            return Result.retry()
        } catch (e: Exception) {
            Log.e(TAG, "✗ Failed to get location: ${e.message}", e)
            return Result.retry()
        }

        if (location == null) {
            Log.w(TAG, "⚠ Location is null — GPS may be off or no cached location available")
            Log.w(TAG, "  Returning success to avoid backoff, will retry next interval")
            return Result.success()
        }

        Log.d(TAG, "✔ Location received:")
        Log.d(TAG, "  Latitude   : ${location.latitude}")
        Log.d(TAG, "  Longitude  : ${location.longitude}")
        Log.d(TAG, "  Accuracy   : ${location.accuracy}m")
        Log.d(TAG, "  Provider   : ${location.provider}")
        Log.d(TAG, "  Age        : ${System.currentTimeMillis() - location.time}ms old")

        // ── Step 2: Save to Realm ─────────────────────────────────────
        Log.d(TAG, "⏳ Saving location to Realm database...")

        return try {
            val realm = RealmManager.realm

            val savedEntry = realm.writeBlocking {
                copyToRealm(
                    LocationHistory().apply {
                        this.userId = userId
                        this.latitude = location.latitude
                        this.longitude = location.longitude
                        this.timestamp = System.currentTimeMillis()
                    }
                )
            }

            // Count total records for this user
            val totalCount = realm.query<LocationHistory>(
                "userId == $0",
                userId
            ).count().find()

            Log.d(TAG, "✔ Location saved to Realm successfully!")
            Log.d(TAG, "  Record ID  : ${savedEntry._id.toHexString()}")
            Log.d(TAG, "  Lat/Lng    : ${savedEntry.latitude}, ${savedEntry.longitude}")
            Log.d(TAG, "  Timestamp  : ${savedEntry.timestamp}")
            Log.d(TAG, "  Total records for user: $totalCount")
            Log.d(TAG, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            Log.d(TAG, "■ Worker COMPLETED SUCCESSFULLY")
            Log.d(TAG, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")

            Result.success()

        } catch (e: Exception) {
            Log.e(TAG, "✗ Failed to save location to Realm: ${e.message}", e)
            Log.e(TAG, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            Log.e(TAG, "■ Worker FAILED — will retry")
            Log.e(TAG, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            Result.retry()
        }
    }
}

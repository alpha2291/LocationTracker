package com.alpha.locationtrackerplayer.background

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.alpha.locationtrackerplayer.data.database.RealmManager
import com.alpha.locationtrackerplayer.data.model.User
import io.github.xilinjia.krdb.ext.query

class BootReceiver : BroadcastReceiver() {

    companion object {
        private const val TAG = "BootReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return

        Log.d(TAG, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        Log.d(TAG, "▶ BroadcastReceiver triggered")
        Log.d(TAG, "  Action: $action")

        val isBootAction = action == Intent.ACTION_BOOT_COMPLETED ||
                action == "android.intent.action.QUICKBOOT_POWERON" ||
                action == "android.intent.action.REBOOT"

        if (!isBootAction) {
            Log.d(TAG, "  Not a boot action — ignoring")
            Log.d(TAG, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            return
        }

        Log.d(TAG, "✔ Boot action confirmed — checking for logged-in user...")

        try {
            val realm = RealmManager.realm
            val loggedUser = realm.query<User>("isLoggedIn == true").first().find()

            if (loggedUser != null) {
                val userId = loggedUser._id.toHexString()
                Log.d(TAG, "✔ Found logged-in user: $userId")
                Log.d(TAG, "  Email: ${loggedUser.email}")

                LocationScheduler.start(context, userId)

                Log.d(TAG, "✔ Worker and foreground service restarted after boot")
            } else {
                Log.d(TAG, "⚠ No logged-in user found — skipping restart")
            }

        } catch (e: Exception) {
            Log.e(TAG, "✗ Error in BootReceiver: ${e.message}", e)
        }

        Log.d(TAG, "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    }
}

package com.alpha.locationtrackerplayer.ui.Location


import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.alpha.locationtrackerplayer.background.LocationScheduler
import com.alpha.locationtrackerplayer.data.database.RealmManager
import com.alpha.locationtrackerplayer.data.model.User
import com.alpha.locationtrackerplayer.navigation.LocalNavigator
import com.alpha.locationtrackerplayer.navigation.Screen
import com.alpha.locationtrackerplayer.viewModels.LocationViewModel
import io.github.xilinjia.krdb.ext.query

@Composable
fun LocationListScreen() {

    val navigator = LocalNavigator.current
    val viewModel: LocationViewModel = viewModel()
    val realm = RealmManager.realm
    val context = LocalContext.current

    val locations by viewModel.locations.collectAsState()

    val loggedUser = remember {
        realm.query<User>("isLoggedIn == true").first().find()
    }
    val userId = remember { loggedUser?._id?.toHexString() ?: "" }

    LaunchedEffect(userId) {
        if (userId.isNotEmpty()) {
            viewModel.loadLocations(userId)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = "Locations", style = androidx.compose.material3.MaterialTheme.typography.headlineMedium)
            Button(onClick = {
                LocationScheduler.stop(context)
                realm.writeBlocking {
                    val user = query<User>("isLoggedIn == true").first().find()
                    findLatest(user!!)?.isLoggedIn = false
                }
                navigator.clearAndNavigate(Screen.LoginScreen)
            }) {
                Text("Logout")
            }
        }

        if (locations.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = androidx.compose.ui.Alignment.Center
            ) {
                Text("No locations recorded yet.")
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(locations) { location ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                navigator.navigate(Screen.MapScreen(userId))
                            }
                            .padding(16.dp)
                    ) {
                        Column {
                            Text(text = "Latitude: ${location.latitude}")
                            Text(text = "Longitude: ${location.longitude}")
                            Text(text = location.timestamp.toString())
                        }
                    }
                }
            }
        }

    }

}
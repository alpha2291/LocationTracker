package com.alpha.locationtrackerplayer.ui.map



import android.view.ViewGroup
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.alpha.locationtrackerplayer.data.database.RealmManager
import com.alpha.locationtrackerplayer.data.model.LocationHistory
import io.github.xilinjia.krdb.ext.query
import org.osmdroid.config.Configuration
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun MapScreen(
    userId: String
) {

    val context = LocalContext.current
    val realm = RealmManager.realm

    val locations = remember {

        realm.query<LocationHistory>(
            "userId == $0 SORT(timestamp ASC)",
            userId
        ).find()

    }

    AndroidView(
        factory = {

            Configuration.getInstance().userAgentValue = context.packageName

            val mapView = MapView(context)

            mapView.layoutParams =
                ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )

            mapView.setMultiTouchControls(true)

            if (locations.isNotEmpty()) {

                val controller = mapView.controller
                controller.setZoom(17.0)

                val start = GeoPoint(
                    locations.first().latitude,
                    locations.first().longitude
                )

                controller.setCenter(start)

                val colors = listOf(
                    0xFFFF0000.toInt(),
                    0xFF2196F3.toInt(),
                    0xFF4CAF50.toInt(),
                    0xFFFF9800.toInt(),
                    0xFF9C27B0.toInt()
                )

                for (i in locations.indices) {

                    val point = GeoPoint(
                        locations[i].latitude,
                        locations[i].longitude
                    )

                    val marker = Marker(mapView)

                    marker.position = point
                    marker.setAnchor(
                        Marker.ANCHOR_CENTER,
                        Marker.ANCHOR_BOTTOM
                    )

                    val date =
                        SimpleDateFormat(
                            "dd MMM yyyy HH:mm",
                            Locale.getDefault()
                        ).format(Date(locations[i].timestamp))

                    marker.title = "Location ${i + 1}"
                    marker.snippet = date

                    mapView.overlays.add(marker)

                    if (i < locations.size - 1) {

                        val next = GeoPoint(
                            locations[i + 1].latitude,
                            locations[i + 1].longitude
                        )

                        val polyline = Polyline()

                        polyline.setPoints(
                            listOf(point, next)
                        )

                        polyline.color =
                            colors[i % colors.size]

                        polyline.width = 8f

                        mapView.overlays.add(polyline)

                    }

                }

            }

            mapView
        }
    )

}
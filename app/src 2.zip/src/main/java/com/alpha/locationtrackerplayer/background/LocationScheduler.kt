package com.alpha.locationtrackerplayer.background


import android.content.Context
import androidx.work.*
import java.util.concurrent.TimeUnit

object LocationScheduler {

    fun start(context: Context, userId: String) {

        val data = workDataOf(
            "userId" to userId
        )

        val request =
            PeriodicWorkRequestBuilder<LocationWorker>(
                15,
                TimeUnit.MINUTES
            )
                .setInputData(data)
                .build()

        WorkManager.getInstance(context)
            .enqueueUniquePeriodicWork(
                "locationTracking",
                ExistingPeriodicWorkPolicy.UPDATE,
                request
            )

    }

}
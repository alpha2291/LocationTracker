package com.alpha.locationtrackerplayer.background


import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.alpha.locationtrackerplayer.data.database.RealmManager
import com.alpha.locationtrackerplayer.data.model.LocationHistory
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.tasks.await

class LocationWorker(
    context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    override suspend fun doWork(): Result {

        val fusedLocationClient =
            LocationServices.getFusedLocationProviderClient(applicationContext)

        val location = fusedLocationClient.lastLocation.await()

        if (location != null) {

            val realm = RealmManager.realm

            realm.writeBlocking {

                copyToRealm(
                    LocationHistory().apply {

                        userId = inputData.getString("userId") ?: ""

                        latitude = location.latitude

                        longitude = location.longitude

                        timestamp = System.currentTimeMillis()

                    }
                )

            }

        }

        return Result.success()

    }

}
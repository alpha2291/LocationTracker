package com.alpha.locationtrackerplayer.ui.auth


import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.alpha.locationtrackerplayer.data.database.RealmManager
import com.alpha.locationtrackerplayer.data.model.User
import com.alpha.locationtrackerplayer.navigation.LocalNavigator
import com.alpha.locationtrackerplayer.navigation.Screen
import io.github.xilinjia.krdb.ext.query

@Composable
fun SignupScreen() {

    val navigator = LocalNavigator.current
    val realm = RealmManager.realm

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.Center
    ) {

        Text(
            text = "Sign Up",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(24.dp))

        TextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        TextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            modifier = Modifier.fillMaxWidth()
        )

        if (errorMessage.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = errorMessage, color = MaterialTheme.colorScheme.error)
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                if (email.isBlank() || password.isBlank()) {
                    errorMessage = "Email and password cannot be empty"
                    return@Button
                }

                val existing = realm.query<User>("email == $0", email).first().find()
                if (existing != null) {
                    errorMessage = "An account with this email already exists"
                    return@Button
                }

                realm.writeBlocking {
                    copyToRealm(User().apply {
                        this.email = email
                        this.password = password
                        this.isLoggedIn = false
                    })
                }

                navigator.navigate(Screen.LoginScreen)
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Sign Up")
        }

        Spacer(modifier = Modifier.height(12.dp))

        TextButton(
            onClick = { navigator.pop() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Already have an account? Login")
        }

    }

}
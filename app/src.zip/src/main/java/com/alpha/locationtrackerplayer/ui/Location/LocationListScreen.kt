package com.alpha.locationtrackerplayer.ui.Location


import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.alpha.locationtrackerplayer.navigation.LocalNavigator
import com.alpha.locationtrackerplayer.navigation.Screen
import com.alpha.locationtrackerplayer.viewModels.LocationViewModel

@Composable
fun LocationListScreen() {

    val navigator = LocalNavigator.current
    val viewModel: LocationViewModel = viewModel()

    val locations by viewModel.locations.collectAsState()

    val userId = remember { "" }

    LaunchedEffect(Unit) {
        viewModel.loadLocations(userId)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize()
    ) {

        items(locations) { location ->

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {

                        navigator.navigate(
                            Screen.MapScreen(userId)
                        )

                    }
                    .padding(16.dp)
            ) {

                Column {

                    Text(text = "Latitude: ${location.latitude}")

                    Text(text = "Longitude: ${location.longitude}")

                    Text(text = location.timestamp.toString())

                }

            }

        }

    }

}
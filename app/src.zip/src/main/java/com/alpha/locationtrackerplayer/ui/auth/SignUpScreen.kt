package com.alpha.locationtrackerplayer.ui.auth


import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.alpha.locationtrackerplayer.data.database.RealmManager
import com.alpha.locationtrackerplayer.data.model.User
import com.alpha.locationtrackerplayer.navigation.LocalNavigator
import com.alpha.locationtrackerplayer.navigation.Screen
import io.github.xilinjia.krdb.ext.query

@Composable
fun SignupScreen() {

    val navigator = LocalNavigator.current
    val realm = RealmManager.realm

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.Center
    ) {

        TextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") }
        )

        Spacer(modifier = Modifier.height(16.dp))

        TextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") }
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {

                realm.writeBlocking {

                    val user = query<User>(
                        "email == $0 AND password == $1",
                        email,
                        password
                    ).first().find()

                    user?.let {
                        it.isLoggedIn = true
                    }

                }

                navigator.navigate(Screen.LoginScreen)

            }
        ) {
            Text("Signup")
        }

    }

}
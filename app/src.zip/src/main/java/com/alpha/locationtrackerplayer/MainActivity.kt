package com.alpha.locationtrackerplayer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.alpha.locationtrackerplayer.data.database.RealmManager.realm
import com.alpha.locationtrackerplayer.data.model.User
import com.alpha.locationtrackerplayer.navigation.AppNavigatorHost
import com.alpha.locationtrackerplayer.ui.theme.LocationTrackerPlayerTheme
import io.github.xilinjia.krdb.ext.query


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val loggedUser = realm.query<User>(
                "isLoggedIn == true"
            ).first().find()

            LocationTrackerPlayerTheme {
                AppNavigatorHost(loggedUser)
            }
        }
    }
}

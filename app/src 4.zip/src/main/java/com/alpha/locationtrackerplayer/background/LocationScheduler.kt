package com.alpha.locationtrackerplayer.background

import android.content.Context
import android.util.Log
import androidx.work.*
import java.util.concurrent.TimeUnit

object LocationScheduler {

    private const val TAG = "LocationScheduler"
    private const val WORK_NAME = "locationTracking"

    fun start(context: Context, userId: String) {

        Log.d(TAG, "Starting location tracking")
        Log.d(TAG, "  UserId  : $userId")
        Log.d(TAG, "  Interval: 15 minutes (flex: 5 min)")

        val data = workDataOf("userId" to userId)

        val constraints = Constraints.Builder()
            .setRequiresBatteryNotLow(false)
            .build()

        val request = PeriodicWorkRequestBuilder<LocationWorker>(
            15, TimeUnit.MINUTES,
            5, TimeUnit.MINUTES
        )
            .setInputData(data)
            .setConstraints(constraints)
            .setBackoffCriteria(BackoffPolicy.LINEAR, 10, TimeUnit.MINUTES)
            .build()

        WorkManager.getInstance(context)
            .enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                request
            )

        Log.d(TAG, "WorkManager job enqueued (name: $WORK_NAME)")

        val serviceIntent = LocationForegroundService.startIntent(context)
        context.startForegroundService(serviceIntent)

        Log.d(TAG, "Foreground service started")
    }

    fun stop(context: Context) {
        Log.d(TAG, " Stopping location tracking")

        WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        Log.d(TAG, "WorkManager job cancelled")

        val serviceIntent = LocationForegroundService.stopIntent(context)
        context.startService(serviceIntent)
        Log.d(TAG, "Foreground service stop requested")
    }
}

